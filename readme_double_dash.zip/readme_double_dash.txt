input.html and output.html are linked

Use example :
- open input.html in the main screen of your laptop
- then open output.html in another tab in secondary screen
- the changes in the input is recorded and launched in the output tab
- use the "Send" buton in the input to show text or image in the secondary screen (output)

Not perfect but may help !

Author : Mampianina